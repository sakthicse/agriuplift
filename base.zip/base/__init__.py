"""Application base, containing global templates."""
